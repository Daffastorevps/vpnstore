#!/bin/bash

# ===== COLORS =====
RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[33m"
CYAN="\e[36m"
ENDCOLOR="\e[0m"

clear

# ===== HEADER =====
echo -e "${CYAN}========================================${ENDCOLOR}"
echo -e "${CYAN}           USER MANAGEMENT TOOL         ${ENDCOLOR}"
echo -e "${CYAN}========================================${ENDCOLOR}"
echo ""

# ===== Tampilkan Semua User =====
allusers=$(awk -F: '$3>=1000 {print $1}' /etc/passwd | grep -v nobody)
echo -e "${GREEN}List of users:${ENDCOLOR}"
echo -e "${GREEN}$allusers${ENDCOLOR}"
echo -e "${CYAN}----------------------------------------${ENDCOLOR}"
echo ""

# ===== Hapus User =====
echo -ne "${YELLOW}Enter the name of the user to be deleted: ${ENDCOLOR}"; read username

echo -e "${CYAN}----------------------------------------${ENDCOLOR}"
while true; do
    read -p "Do you want to delete the user '$username'? (Y/N) " yn
    case $yn in
        [Yy]* )
            if id "$username" &>/dev/null; then
                if userdel "$username"; then
                    echo -e "${GREEN}User '$username' deleted successfully.${ENDCOLOR}"
                else
                    echo -e "${RED}Failed to delete user '$username'.${ENDCOLOR}"
                fi
            else
                echo -e "${RED}User '$username' does not exist.${ENDCOLOR}"
            fi
            break
            ;;
        [Nn]* )
            echo -e "${YELLOW}Delete cancelled.${ENDCOLOR}"
            break
            ;;
        * )
            echo -e "${RED}Please answer Y or N.${ENDCOLOR}"
            ;;
    esac
done

echo -e "${CYAN}========================================${ENDCOLOR}"
echo -e "Press Enter to return to main menu"; read
menu